//
//  IAPReceiptServer.h
//  SDK-IAP
//
//  Created by zhangerbing on 2019/12/2.
//  Copyright © 2019 zhangerbing. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IAPCheckOrderModel.h"

/// 这个类主要与业务服务器交互，将本地票据传给服务器，服务器与苹果服务进行验证。这个类不用公开
/// 具体可参考：
/// https://developer.apple.com/library/archive/releasenotes/General/ValidateAppStoreReceipt/Chapters/ValidateRemotely.html#//apple_ref/doc/uid/TP40010573-CH104-SW1
/// https://developer.apple.com/library/archive/releasenotes/General/ValidateAppStoreReceipt/Chapters/ReceiptFields.html#//apple_ref/doc/uid/TP40010573-CH106-SW20

NS_ASSUME_NONNULL_BEGIN

@class IAPSubscriptionModel;

typedef void(^IAPSDKValidateSuccessBlock)(NSArray<IAPSubscriptionModel *> * _Nullable);
typedef void(^IAPSDKLocalValidateSuccessBlock)(IAPCheckOrderModel *response);
typedef void(^IAPSDKValidateFailureBlock)(NSError *error);
typedef void(^IAPSDKPayNotificationBlock)(BOOL paySuccess);

@interface IAPReceiptServer : NSObject

/// 验证票据
/// @param receipt 交易的票据（base64的字符串）
/// @param password 应用共享密钥（在store connect后台上对应的应用里创建，需要在SDK初始化配置好）
/// @param excludeOldTransaction 是否除去旧订单，只拿最新有效的订单
+ (void)validateReceipt:(NSString *)receipt
               password:(NSString *)password
             excludeOld:(BOOL)excludeOldTransaction
                success:(IAPSDKLocalValidateSuccessBlock)success
                failure:(IAPSDKValidateFailureBlock)failure;


/// 支付上报
/// @param productId 苹果商品id
/// @param receipt 票据
+ (void)payNotificationWithProductId:(NSString *)productId
                             receipt:(NSString *)receipt
                             success:(IAPSDKPayNotificationBlock)success
                             failure:(IAPSDKValidateFailureBlock)failure;


/// 查询有效的订阅状态
/// @param receipt 票据
+ (void)subscriptionStatusWithReceipt:(NSString *)receipt
                              success:(IAPSDKValidateSuccessBlock)success
                              failure:(IAPSDKValidateFailureBlock)failure;


/// 获取服务器时间
+ (void)getServerTimeInterval:(void(^)(NSTimeInterval timeInterval))completion;

@end

NS_ASSUME_NONNULL_END
