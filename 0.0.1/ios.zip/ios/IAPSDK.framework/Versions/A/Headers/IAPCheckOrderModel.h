//
//  IAPCheckOrderModel.h
//  SDK-IAP
//
//  Created by zhangerbing on 2019/12/2.
//  Copyright © 2019 zhangerbing. All rights reserved.
//

#import <Foundation/Foundation.h>

/// 验证票据返回的数据结构
/// 具体字段意义参考：https://developer.apple.com/library/archive/releasenotes/General/ValidateAppStoreReceipt/Chapters/ReceiptFields.html#//apple_ref/doc/uid/TP40010573-CH106-SW20

NS_ASSUME_NONNULL_BEGIN

@interface IAPCheckOrderModel : NSObject

/// 当前状态，0代表成功
@property (assign, nonatomic) NSInteger status;

/// 当前环境，Sandbox 为沙盒环境
@property (copy, nonatomic) NSString *environment;

/// receipt解析出来的信息，包含一个in_app的数组，是所有订单信息
@property (copy, nonatomic) NSDictionary *receipt;

/// 最新的凭证信息，不同组不同类型的商品都会出现，同一个组的订阅，会被替换成最新的订阅
/// 最好结合pending_renewal_info来判断
// {
//    "quantity":"1",
//    "product_id":"iapsdk_downloadable_id",
//    "transaction_id":"1000000599556707",
//    "original_transaction_id":"1000000599556707",
//    "purchase_date":"2019-12-02 03:32:47 Etc/GMT",
//    "purchase_date_ms":"1575257567000",
//    "purchase_date_pst":"2019-12-01 19:32:47 America/Los_Angeles",
//    "original_purchase_date":"2019-12-02 03:32:47 Etc/GMT",
//    "original_purchase_date_ms":"1575257567000",
//    "original_purchase_date_pst":"2019-12-01 19:32:47 America/Los_Angeles",
//    "is_trial_period":"false"
//},
//{
//    "quantity":"1",
//    "product_id":"iapsdk_year_id",
//    "transaction_id":"1000000599900668",
//    "original_transaction_id":"1000000599546393",
//    "purchase_date":"2019-12-02 16:01:07 Etc/GMT",
//    "purchase_date_ms":"1575302467000",
//    "purchase_date_pst":"2019-12-02 08:01:07 America/Los_Angeles",
//    "original_purchase_date":"2019-12-02 02:36:23 Etc/GMT",
//    "original_purchase_date_ms":"1575254183000",
//    "original_purchase_date_pst":"2019-12-01 18:36:23 America/Los_Angeles",
//    "expires_date":"2019-12-02 17:01:07 Etc/GMT",
//    "expires_date_ms":"1575306067000",
//    "expires_date_pst":"2019-12-02 09:01:07 America/Los_Angeles",
//    "web_order_line_item_id":"1000000048678256",
//    "is_trial_period":"false",
//    "is_in_intro_offer_period":"false",
//    "subscription_group_identifier":"20578013"
//}
@property (copy, nonatomic) NSArray *latest_receipt_info;

/// 订阅等待更新的信息，同一组的订阅商品会被更新，不同组的会同时出现，要区分商品id
/// 示例：
//[{
//    "expiration_intent":"1",
//    "auto_renew_product_id":"iapsdk_year_id",
//    "original_transaction_id":"1000000599546393",
//    "is_in_billing_retry_period":"0",
//    "product_id":"iapsdk_year_id",
//    "auto_renew_status":"0"
//}]
@property (copy, nonatomic) NSArray *pending_renewal_info;

@end

NS_ASSUME_NONNULL_END
