//
//  IAPDeviceModel.h
//  SDK-IAP
//
//  Created by zhangerbing on 2019/12/25.
//  Copyright © 2019 zhangerbing. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface IAPDeviceModel : NSObject

// 设备ID，如果无法获取，SDK需要手动生成，然后保存在本地。(非空)
@property (strong, nonatomic) NSString *did;

// 设备类型，1=Android，2=IOS， 3=H5  (非空)
@property (assign, nonatomic) NSInteger dtype;

// 语言代码，2位小写，采用ISO 639-1标准，例如：en (非空)
@property (strong, nonatomic) NSString *lang;

// 地区代码，2位大写，采用ISO 3166-1标准，例如：US (非空)
@property (strong, nonatomic) NSString *country;

// 用户sim卡所在的国家
@property (strong, nonatomic) NSString *country_sim;

// 网络类型，unknown,wifi,gprs,3g,4g
@property (strong, nonatomic) NSString *net_type;

// 渠道号
@property (strong, nonatomic) NSString *channel;

// 机型
@property (strong, nonatomic) NSString *phone_model;

// 客户端App版本号 (非空)
@property (strong, nonatomic) NSString *app_version_number;

// 客户端App版本名称
@property (strong, nonatomic) NSString *app_version_name;

// 操作系统版本名
@property (strong, nonatomic) NSString *system_version_name;

+ (NSDictionary *)dictionary;

+ (NSString *)jsonString;

@end

NS_ASSUME_NONNULL_END
