//
//  IAPSubscriptionModel.h
//  IAPSDK
//
//  Created by zhangerbing on 2020/1/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface IAPSubscriptionModel : NSObject

@property (copy  , nonatomic) NSString *expiry_time;
@property (copy  , nonatomic) NSString *product_id;
@property (copy  , nonatomic) NSString *start_time;
@property (copy  , nonatomic) NSString *tran_id;
@property (copy  , nonatomic) NSString *transaction_id;
@property (copy  , nonatomic) NSString *origin_transaction_id;
@property (assign, nonatomic) BOOL is_trial_period;

@end

NS_ASSUME_NONNULL_END
