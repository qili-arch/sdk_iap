//
//  IAPManager.h
//  SDK-IAP
//
//  Created by zhangerbing on 2019/11/29.
//  Copyright © 2019 zhangerbing. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <StoreKit/StoreKit.h>
#import "IAPCheckOrderModel.h"
#import "IAPSubscriptionModel.h"

NS_ASSUME_NONNULL_BEGIN

@class IAPManager;
@protocol IAPManagerDelegate <NSObject>

/// 没有开启IAP权限
/// iOS 12 以后关闭的入口改为了：设置-->屏幕使用时间-->内容和隐私访问限制-->iTunes Store与App Store购买项目-->App内购买项目
/// @param manager iAPManager
- (void)managerNoPermission:(IAPManager *)manager;

@optional

/// 请求苹果商品的回调
/// @param manager  IAPManager
/// @param request SKProductsRequest
/// @param products 苹果商品列表
- (void)manager:(IAPManager *)manager productsRequest:(nonnull SKProductsRequest *)request didReceiveProducts:(NSArray<SKProduct *> *)products;


/// 请求苹果商品失败的回调
/// @param manager IAPManager
/// @param request SKRequest
/// @param error 错误原因
- (void)manager:(IAPManager *)manager request:(SKRequest *)request didFailWithError:(NSError *)error;


/// 交易成功的回调
/// @param manager IAPManager
/// @param productModel 数据
/// @param transaction 此次交易事务
- (void)manager:(IAPManager *)manager iapSuccess:(IAPCheckOrderModel *)productModel transaction:(SKPaymentTransaction *)transaction;


/// 交易失败的回调
/// @param manager IAPManager
/// @param transaction 此次交易事务
/// @param error 具体错误
- (void)manager:(IAPManager*) manager iapFail:(SKPaymentTransaction *)transaction error:(NSError *)error;


#warning 这里不知道原SDK是怎么实现的，因为在订阅期内重复订阅一个商品id，苹果会弹一个重复购买的系统弹窗，但状态会走到 SKPaymentTransactionStatePurchased 。所以可能是在验单流程判断的，所以这里没有实现。
/// 重复支付
/// @param manager IAPManager
/// @param transaction 此次交易事务
//- (void)manager:(IAPManager *)manager iapRepeat:(SKPaymentTransaction *)transaction;


/// 恢复购买
/// @param manager IAPManager
/// @param subscriptionInfos 订阅信息数据数组
- (void)manager:(IAPManager *)manager iapRestore:(NSArray<IAPSubscriptionModel *> *)subscriptionInfos;


/// 恢复购买失败
/// @param queue 支付队列
/// @param error 具体错误
- (void)manager:(IAPManager *)manager paymentQueue:(SKPaymentQueue *)queue restoreCompletedTransactionsFailedWithError:(NSError *)error;

@end


typedef void(^IAPFetchProductBlock)(NSArray<SKProduct *> * _Nullable products);

@interface IAPManager : NSObject

@property (weak, nonatomic) id<IAPManagerDelegate> delegate;

+ (instancetype)sharedManager;

/// 刷新苹果商品
/// @param identifiesList 苹果商品id的 Set 实例
- (void)refreshAllProductsWithIdentifies:(NSSet <NSString *> *)identifiesList;

/// 请求苹果商品
/// @discussion 实际上与上面的接口是一样的，只是回调改成block，而且不会同时触发两类回调。主要使用场景不一致，这个接口可以适用于配置的id不同，而且进行动态生成商品进行订阅。如果使用代理回调，在上层则会在管理订阅流程上进行复杂的条件判断。
/// @param identifiesList 商品id集合
/// @param completion 完成回调
- (void)fetchProductWithIdentifies:(NSSet<NSString *> *)identifiesList completion:(IAPFetchProductBlock)completion;

/// 获取当前有效的订阅信息
- (void)fetchCurrentSubscriptionInfo:(void (^)(NSArray<IAPSubscriptionModel *> * _Nullable subInfos, NSError * _Nullable error))result;

/// 购买苹果商品
/// @param product 苹果商品实例
/// @param purpose 原来SDK存在的一个参数，可能用于统计区别购买和订阅用的。“PRODUCT_PURCHASE”，"PRODUCT_SUBSCRIPTION" 和 "VCOIN_RECHARGE"
- (void)payWithProduct:(SKProduct *)product withPurpose:(NSString *)purpose;

/// 恢复购买
- (void)restoreTransactions;

/// 获取当前时间戳(毫秒级别)
- (void)getCurrentServiceTimeIntervalComplete:(void (^)(NSTimeInterval timeInterval))complete;

@end

NS_ASSUME_NONNULL_END
