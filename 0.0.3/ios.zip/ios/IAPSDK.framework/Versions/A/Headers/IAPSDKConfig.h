//
//  IAPSDKConfig.h
//  SDK-IAP
//
//  Created by zhangerbing on 2019/12/2.
//  Copyright © 2019 zhangerbing. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString * const IAP_PURPOSE_PURCHASE;
extern NSString * const IAP_PURPOSE_RECHARGE;
extern NSString * const IAP_PURPOSE_SUBCRIPTION;

@interface IAPSDKConfig : NSObject

@property (class, copy, nonatomic, readonly) NSString *domain;

@property (class, copy, nonatomic, readonly) NSString *timeDomain;

@property (class, copy, nonatomic, readonly) NSString *clientID;

@property (class, copy, nonatomic, readonly) NSString *signatureKey;

@property (class, copy, nonatomic, readonly) NSString *desKey;

@property (class, copy, nonatomic, readonly) NSString *appId;

@property (class, copy, nonatomic, readonly) NSString *password;

// 两个初始化方法都要配置，产品信息一定要在 AppDelegate 的 -didFinishLaunchingWithOptions: 的时机调用。
// 域名配置的理论上在进行订阅之前配置即可，但还是建议同时初始化，容易管理。

/// SDK初始化需要配置的域名
/// @param mainDomain 申请的域名，一级域名
/// @param timeDomain 申请的域名，广告时间服务
+ (void)configMainDomain:(NSString *)mainDomain timeDomain:(NSString *)timeDomain;

/// SDK初始化配置产品信息
/// @param clientID 产品id，向服务器申请
/// @param signatureKey 签名密钥，向服务器申请
/// @param desKey DES加密key，向服务器申请
/// @param appId 苹果的应用ID
/// @param password 苹果应用后台对应APP的共享密钥
+ (void)configClientID:(NSString *)clientID signatureKey:(NSString *)signatureKey desKey:(NSString *)desKey appId:(NSString *)appId password:(NSString *)password;


@end

NS_ASSUME_NONNULL_END
